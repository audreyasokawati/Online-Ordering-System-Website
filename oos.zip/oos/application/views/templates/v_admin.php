<div class="container-fluid">
  <div class="row">
    <nav class="col-md-2 d-none d-md-block bg-light sidebar">
      <div class="sidebar-sticky">
        <ul class="nav flex-column">
          <li class="nav-item">
            <br>
            <br>
              <a href="<?= base_url('cmenus') ?>" class="col-lg-9 btn btn-primary mt-3 float-right">Admin</a>
              <a href="<?= base_url('cmenus/list') ?>" class="col-lg-9 btn btn-warning mt-2 float-right">List Menu</a>
              <a href="<?= base_url('ckasir/index') ?>" class="col-lg-9 btn btn-warning mt-2 float-right">Kasir</a>
              <a href="<?= base_url('cusers/listUsers') ?>" class="col-lg-9 btn btn-warning mt-2 float-right">User</a> 
              <a href="<?= base_url('ccodes/index') ?>" class="col-lg-9 btn btn-warning mt-2 float-right">Code</a>
          </li>
        </ul>
      </div>
    </nav>

    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <section class="konten">
    <br>